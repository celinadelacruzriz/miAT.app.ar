export const CAFECITO_URL = "https://cafecito.app/miatappar"
